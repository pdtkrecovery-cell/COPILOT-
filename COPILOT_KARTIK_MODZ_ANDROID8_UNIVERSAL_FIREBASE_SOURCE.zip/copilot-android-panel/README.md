# COPILOT ANDROID PANEL © KARTIK MODZ

A premium-dark, root-gated Android companion app with Firebase-backed online access-key activation and best-effort Magisk, KernelSU, and APatch environment detection.
This starter intentionally does **not** implement game cheats, ESP, silent aim, knockdown
manipulation, memory editing, anti-cheat bypasses, or game-process injection.

## Included
- Kotlin + Jetpack Compose Android app
- Root environment check for Magisk, KernelSU, and APatch (best-effort detection; grants are requested by `su`)
- Firebase Anonymous Authentication
- Callable Cloud Functions: `verifyKey`, `createKey`, `revokeKey`
- Server-side SHA-256 key storage (plaintext is returned only once at creation)
- First-install binding, expiry, and revocation
- Firestore rules deny all direct client access

## 1. Create Firebase project
1. Create a project in the Firebase Console.
2. Add an Android app with package name `com.copilot.microsoft`.
3. Download `google-services.json` and place it at `app/google-services.json`.
4. In Firebase Authentication, enable **Anonymous** sign-in.
5. Create a Firestore database.
6. Install Firebase CLI and log in: `npm install -g firebase-tools` then `firebase login`.
7. From the `firebase` folder run `firebase use --add` and select your project.

## 2. Deploy the server
Use Node.js 20. From the `firebase` folder:
```bash
cd functions
npm install
cd ..
firebase deploy --only firestore:rules,functions
```

## 3. Grant an administrator account
Create/sign in to the intended admin account once (anonymous auth is fine for a private test).
Get that user's Firebase Auth UID from Authentication > Users.
From a trusted machine with Firebase Admin SDK credentials, run this one-time script:

```js
const { initializeApp, applicationDefault } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
initializeApp({ credential: applicationDefault(), projectId: "YOUR_FIREBASE_PROJECT_ID" });
getAuth().setCustomUserClaims("ADMIN_UID_FROM_CONSOLE", { admin: true });
```

Do not put service-account credentials in the Android app or commit them to source control.
The admin must sign out and sign in again so the custom claim refreshes.

## 4. Create/revoke keys
Call `createKey` from a trusted admin client while signed in as the admin:
```js
const result = await firebase.functions().httpsCallable("createKey")({ durationDays: 7 });
console.log(result.data.key); // show/store securely; only returned once
```
Use `durationDays: 1`, `7`, `30`, or `null` for lifetime.
To revoke:
```js
await firebase.functions().httpsCallable("revokeKey")({ key: "COPILOT-..." });
```
The functions enforce the admin custom claim. Never expose admin credentials or bypass this check.

## 5. Build Android app
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then build.
The app expects Firebase project config at `app/google-services.json`.

## Important production hardening
- This is a starter implementation, not a production anti-abuse system.
- Installation ID is app-generated and can be reset by reinstalling/clearing app data. For stronger binding, add Play Integrity verification and server-side attestation.
- Add App Check enforcement for callable functions after configuring the Android App Check provider.
- Add rate limiting / abuse monitoring and a proper admin web console before public release.
- Consider requiring registered email/phone admin accounts rather than anonymous admin accounts.
- Keep Firebase service-account keys only in a secure server environment.
- Add your own privacy policy and support contact before distribution.

## Branding
The app displays `COPILOT` and `© KARTIK MODZ`. Ensure you own or are authorized to use the branding.


## Rooted-device behavior
- The app checks whether `su -c id` can obtain UID 0.
- It makes a best-effort attempt to identify Magisk, KernelSU, or APatch using common on-device paths.
- Key activation is disabled unless root access is granted.
- Detection can vary by ROM, root manager version, and configuration. A missing manager label does not prove the device is unrooted.
- The app does not conceal root, tamper with games, bypass anti-cheat, or promise an "anti-ban" result.


## Requested APK configuration
- Minimum Android version: API 26 (Android 8.0 Oreo).
- APK packaging: Universal (no ABI split configuration; Gradle produces a single APK containing supported app code).


## Firebase configuration supplied for this build
- Firebase project ID: `copilot-microsof`
- Registered Android package: `com.copilot.microsoft`
- `app/google-services.json` is already included in this project.
- Android minimum version is API 26 (Android 8.0).
- No ABI filters are set, so Gradle can package supported ABIs as a universal APK.

The Firebase Android configuration file is public client configuration, not an admin credential.
Keep service-account credentials and other server secrets out of the Android app.
