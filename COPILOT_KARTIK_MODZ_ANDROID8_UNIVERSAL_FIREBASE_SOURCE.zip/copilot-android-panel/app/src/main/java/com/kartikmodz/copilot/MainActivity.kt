package com.kartikmodz.copilot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import java.util.UUID

private val Background = Color(0xFF080D18)
private val Panel = Color(0xFF121C2D)
private val Cyan = Color(0xFF35D9F2)
private val Muted = Color(0xFF9AAAC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CopilotApp() }
    }
}

@Composable
fun CopilotApp() {
    var key by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Connect to activate your access key.") }
    var busy by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf(false) }
    var rootStatus by remember { mutableStateOf("Checking root access…") }
    var rootManager by remember { mutableStateOf("Unknown") }
    var isRooted by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        val result = RootEnvironment.check()
        isRooted = result.first
        rootManager = result.second
        rootStatus = if (isRooted) "Root access available" else "Root access not available"
    }

    val auth = remember { FirebaseAuth.getInstance() }
    val functions = remember { FirebaseFunctions.getInstance() }
    val prefs = androidx.compose.ui.platform.LocalContext.current
        .getSharedPreferences("copilot_local", android.content.Context.MODE_PRIVATE)
    val installId = remember {
        prefs.getString("installation_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("installation_id", it).apply()
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Background, surface = Panel,
            onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Background) {
            Column(
                Modifier.fillMaxSize().padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("COPILOT", color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        Text("ANDROID COMPANION PANEL", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF123541), shape = RoundedCornerShape(30.dp)) {
                        Text("ONLINE KEY", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null,
                                tint = if (isRooted) Cyan else Color(0xFFFFB454))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("ROOT ENVIRONMENT", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("$rootManager • $rootStatus", color = Muted, fontSize = 11.sp)
                            }
                            Text(if (isRooted) "READY" else "LOCKED",
                                color = if (isRooted) Cyan else Color(0xFFFFB454),
                                fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("ACCESS ACTIVATION", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Enter the key supplied by the administrator.", color = Muted, fontSize = 13.sp)
                        OutlinedTextField(
                            value = key, onValueChange = { key = it.uppercase().trim() },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Access key") },
                            placeholder = { Text("COPILOT-XXXX-XXXX") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Characters,
                                keyboardType = KeyboardType.Ascii
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Cyan, focusedLabelColor = Cyan,
                                cursorColor = Cyan, unfocusedBorderColor = Color(0xFF33445D)
                            )
                        )
                        Button(
                            onClick = {
                                if (!isRooted) { status = "COPILOT requires a rooted device with an approved root manager."; return@Button }
                                if (key.isBlank()) { status = "Enter an access key first."; return@Button }
                                busy = true
                                status = "Checking key with secure server…"
                                auth.signInAnonymously()
                                    .addOnSuccessListener {
                                        val data = hashMapOf("key" to key, "installationId" to installId)
                                        functions.getHttpsCallable("verifyKey").call(data)
                                            .addOnSuccessListener { result ->
                                                val response = result.data as? Map<*, *>
                                                active = response?.get("active") == true
                                                status = if (active) {
                                                    "Key activated. Your access is valid until " +
                                                        (response?.get("expiresAt") ?: "lifetime") + "."
                                                } else "Key could not be activated."
                                                busy = false
                                            }
                                            .addOnFailureListener { e ->
                                                status = e.localizedMessage ?: "Activation failed."
                                                busy = false
                                            }
                                    }
                                    .addOnFailureListener { e ->
                                        status = e.localizedMessage ?: "Sign-in failed."
                                        busy = false
                                    }
                            },
                            enabled = !busy && isRooted,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color.Black)
                        ) {
                            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Text("VERIFY & ACTIVATE", fontWeight = FontWeight.Bold)
                        }
                        Text(status, color = if (active) Cyan else Muted, fontSize = 12.sp)
                    }
                }

                Text("ROOT COMPANION TOOLS", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                ToolTile(Icons.Default.Security, "Root environment status", "Magisk, KernelSU and APatch compatibility checks")
                ToolTile(Icons.Default.Speed, "Performance monitor", "View device and gaming performance information")
                ToolTile(Icons.Default.Tune, "Touch & display settings", "Open supported Android display and touch settings")
                ToolTile(Icons.Default.CenterFocusStrong, "Custom crosshair", "Local, non-game-integrated visual overlay concept")
                Spacer(Modifier.weight(1f))
                Text("© KARTIK MODZ  •  ALL RIGHTS RESERVED", color = Muted,
                    modifier = Modifier.fillMaxWidth(), fontSize = 10.sp)
                Text("Independent companion utility. Not affiliated with Garena or Free Fire.",
                    color = Muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun ToolTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
        }
    }
}


/**
 * Best-effort root environment detection for this app's own root-only companion features.
 * This does not hide root, modify games, bypass anti-cheat, or guarantee device integrity.
 */
private object RootEnvironment {
    fun check(): Pair<Boolean, String> {
        val paths = mapOf(
            "Magisk" to listOf("/data/adb/magisk", "/sbin/.magisk", "/data/adb/modules"),
            "KernelSU" to listOf("/data/adb/ksu", "/data/adb/ksud"),
            "APatch" to listOf("/data/adb/ap", "/data/adb/apatch")
        )
        val manager = try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = process.inputStream.bufferedReader().readText()
            val error = process.errorStream.bufferedReader().readText()
            val exit = process.waitFor()
            if (exit == 0 && output.contains("uid=0")) {
                val detected = paths.entries.firstOrNull { entry ->
                    entry.value.any { path -> java.io.File(path).exists() }
                }?.key ?: "Root (manager not identified)"
                true to detected
            } else {
                false to "No root grant"
            }
        } catch (_: Exception) {
            false to "No root manager"
        }
        return manager
    }
}
