const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue, Timestamp } = require("firebase-admin/firestore");
const crypto = require("crypto");

initializeApp();
const db = getFirestore();

function sha256(value) {
  return crypto.createHash("sha256").update(value, "utf8").digest("hex");
}
function requireAdmin(request) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator access required.");
  }
}
function cleanKey(value) {
  return String(value || "").trim().toUpperCase();
}

// Admin-only: creates a key and returns the plaintext key exactly once.
// durationDays: 1, 7, 30, or null for lifetime.
exports.createKey = onCall(async (request) => {
  requireAdmin(request);
  const days = request.data?.durationDays;
  if (days !== null && (![1, 7, 30].includes(Number(days)))) {
    throw new HttpsError("invalid-argument", "durationDays must be 1, 7, 30, or null.");
  }
  const key = "COPILOT-" +
    crypto.randomBytes(4).toString("hex").toUpperCase() + "-" +
    crypto.randomBytes(4).toString("hex").toUpperCase();
  const expiresAt = days === null ? null :
    Timestamp.fromMillis(Date.now() + Number(days) * 24 * 60 * 60 * 1000);

  await db.collection("keys").doc(sha256(key)).create({
    expiresAt,
    createdAt: FieldValue.serverTimestamp(),
    createdBy: request.auth.uid,
    status: "unused",
    boundInstallationId: null
  });
  return { key, expiresAt: expiresAt ? expiresAt.toDate().toISOString() : "lifetime" };
});

// Authenticated users can verify a key. First successful activation binds it to this app install.
exports.verifyKey = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign-in required.");
  const key = cleanKey(request.data?.key);
  const installationId = String(request.data?.installationId || "");
  if (!/^COPILOT-[A-F0-9]{8}-[A-F0-9]{8}$/.test(key) ||
      !/^[a-f0-9-]{36}$/i.test(installationId)) {
    throw new HttpsError("invalid-argument", "Invalid key or installation ID.");
  }

  const ref = db.collection("keys").doc(sha256(key));
  return await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "Key is not valid.");
    const record = snap.data();
    if (record.status === "revoked") throw new HttpsError("permission-denied", "Key was revoked.");
    if (record.expiresAt && record.expiresAt.toMillis() <= Date.now()) {
      throw new HttpsError("deadline-exceeded", "Key has expired.");
    }
    if (record.boundInstallationId && record.boundInstallationId !== installationId) {
      throw new HttpsError("permission-denied", "Key is already bound to another installation.");
    }
    tx.update(ref, {
      status: "active",
      boundInstallationId: installationId,
      activatedAt: record.activatedAt || FieldValue.serverTimestamp(),
      lastVerifiedAt: FieldValue.serverTimestamp(),
      boundUid: record.boundUid || request.auth.uid
    });
    return {
      active: true,
      expiresAt: record.expiresAt ? record.expiresAt.toDate().toISOString() : "lifetime"
    };
  });
});

// Admin-only: revoke by supplying the original key.
exports.revokeKey = onCall(async (request) => {
  requireAdmin(request);
  const key = cleanKey(request.data?.key);
  if (!key) throw new HttpsError("invalid-argument", "Key is required.");
  const ref = db.collection("keys").doc(sha256(key));
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Key not found.");
  await ref.update({ status: "revoked", revokedAt: FieldValue.serverTimestamp() });
  return { revoked: true };
});
